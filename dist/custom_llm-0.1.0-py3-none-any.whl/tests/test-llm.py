from cllm import activation
from cllm.attention import SA
from cllm import ffn
import torch

SEED=42
torch.manual_seed(SEED)


sentence = "For me, you are the priority no matter what"
dc = {s:i for i,s in enumerate(sorted(sentence.replace(',', '').split()))}
sentence_int = torch.tensor([dc[s] for s in sentence.replace(',', '').split()])
print (sentence_int)

vocab_size = 50000
embed = SA.Embedding(vocab_size, 3)
embed_sentence = embed(sentence_int).detach()

print(embed_sentence)
print(embed_sentence.shape)
